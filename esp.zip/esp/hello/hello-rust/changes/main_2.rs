#![no_std]
#![no_main]

use panic_halt as _;

use esp_hal::{
    Config,
    uart::{Uart, Config as UartConfig},
};
use esp_println::println;

esp_bootloader_esp_idf::esp_app_desc!();

// Konstanta
const BAUD: u32 = 9_600;
const SID: u8 = 1;
const REG_START: u16 = 0x0001;
const REG_QTY: u16 = 2;

const SAMPLE_SPIN: u32 = 80_000 * 200 / 4;  // ~200 ms kasar
const TIMEOUT_SPIN: u32 = 80_000 * 60  / 4;  // ~60 ms

#[esp_hal::main]
fn main() -> ! {
    // Inisialisasi board / hal
    let mut p = esp_hal::init(Config::default());

    // Buat UART dengan API dasar
    let mut uart = Uart::new(
        p.UART1,
        UartConfig::default().with_baudrate(BAUD),
    )
    .with_tx(p.GPIO17)
    .with_rx(p.GPIO18)
    .expect("UART1 init failed");

    println!("\n=== SHT20 stream(JSON) ===");

    let mut req = [0u8; 8];
    build_req(&mut req, SID, 0x04, REG_START, REG_QTY);

    loop {
        drain_rx(&mut uart);

        let _ = uart.write(&req);
        let _ = uart.flush();
        short_spin(12_000); // turnaround

        let mut rx = [0u8; 16];
        let mut n = 0usize;
        let mut spins = 0u32;
        while n < 9 && spins < TIMEOUT_SPIN {
            let mut b = [0u8; 1];
            if uart.read(&mut b).is_ok() {
                rx[n] = b[0];
                n += 1;
            } else {
                short_spin(1_000);
            }
            spins += 1;
        }

        let (mut t_opt, mut rh_opt) = (None, None);
        if n == 9 && valid_rsp(&rx[..n], SID, 0x04, 4) {
            let t_raw = u16::from_be_bytes([rx[3], rx[4]]);
            let rh_raw = u16::from_be_bytes([rx[5], rx[6]]);
            t_opt = Some(t_raw as f32 / 10.0);
            rh_opt = Some(rh_raw as f32 / 10.0);
        }

        match (t_opt, rh_opt) {
            (Some(t), Some(rh)) => println!(r#"{{"t":{:.1},"rh":{:.1}}}"#, t, rh),
            _ => print_json_with_nulls(t_opt, rh_opt),
        }

        short_spin(SAMPLE_SPIN);
    }
}

fn drain_rx(uart: &mut Uart<'_>) {
    let mut b = [0u8; 1];
    while uart.read(&mut b).is_ok() {}
}
fn short_spin(n: u32) { for _ in 0..n { core::hint::spin_loop(); } }

fn build_req(buf: &mut [u8; 8], sid: u8, fc: u8, start: u16, qty: u16) {
    buf[0] = sid;
    buf[1] = fc;
    buf[2..4].copy_from_slice(&start.to_be_bytes());
    buf[4..6].copy_from_slice(&qty.to_be_bytes());
    let crc = crc16(&buf[..6]);
    buf[6] = (crc & 0xFF) as u8;
    buf[7] = (crc >> 8) as u8;
}
fn valid_rsp(frame: &[u8], sid: u8, fc: u8, bc: u8) -> bool {
    frame.len() >= 5
        && frame[0] == sid
        && (frame[1] & 0x80) == 0
        && frame[1] == fc
        && frame[2] == bc
        && check_crc(frame)
}
fn crc16(data: &[u8]) -> u16 {
    let mut crc = 0xFFFF;
    for &b in data {
        crc ^= b as u16;
        for _ in 0..8 {
            let lsb = crc & 1;
            crc >>= 1;
            if lsb != 0 {
                crc ^= 0xA001;
            }
        }
    }
    crc
}
fn check_crc(frame: &[u8]) -> bool {
    if frame.len() < 3 { return false; }
    let calc = crc16(&frame[..frame.len()-2]);
    frame[frame.len()-2] == (calc & 0xFF) as u8
        && frame[frame.len()-1] == (calc >> 8) as u8
}
fn print_json_with_nulls(t: Option<f32>, rh: Option<f32>) {
    match (t, rh) {
        (Some(tt), Some(hh)) => println!(r#"{{"t":{:.1},"rh":{:.1}}}"#, tt, hh),
        (Some(tt), None)     => println!(r#"{{"t":{:.1},"rh":null}}"#, tt),
        (None, Some(hh))     => println!(r#"{{"t":null,"rh":{:.1}}}"#, hh),
        (None, None)         => println!(r#"{{"t":null,"rh":null}}"#),
    }
}
