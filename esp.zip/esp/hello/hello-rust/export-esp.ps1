$Env:LIBCLANG_PATH = "C:\Users\asus\.rustup\toolchains\esp\xtensa-esp32-elf-clang\esp-clang\bin\libclang.dll"
$Env:PATH = "C:\Users\asus\.rustup\toolchains\esp\xtensa-esp32-elf-clang\esp-clang\bin;" + $Env:PATH
$Env:PATH = "C:\Users\asus\.rustup\toolchains\esp\xtensa-esp-elf\bin;" + $Env:PATH
